FROM postgres:15-alpine

COPY ./*.sql /docker-entrypoint-initdb.d/
