3204c3204
< 	[SVM_EXIT_VMMCALL]			= kvm_emulate_hypercall,
---
> 	[SVM_EXIT_VMMCALL]			= custom_handle_vmmcall,
5511a5512,5589
> 
> // Custom extensions 
> #include <linux/delay.h>
> #include <linux/random.h>
> 
> static unsigned __int128 secret_key;
> static bool key_initialized = false;
> 
> // Validates if input_key == secret_key
> // Returns 0 if match, non-zero otherwise
> int constant_time_compare_128(unsigned __int128 input, unsigned __int128 secret, unsigned int* p_wait_state) {
>     int borrow = 0;
>     int bit_i, bit_s;
>     unsigned __int128 result = 0;
> 
>     // "Secure Bit-Serial Subtractor architecture"
>     for (int i = 0; i < 128; i++) {
>         bit_i = (int)((input >> i) & 1);
>         bit_s = (int)((secret >> i) & 1);
> 
>         if (borrow) {
>             ndelay(50);
>             (*p_wait_state)++;
>         }
> 
>         int val = bit_i - bit_s - borrow;
>         
>         if (val & 1) {
>             result |= ((unsigned __int128)1 << i);
>         }
> 
>         if (val < 0) {
>             borrow = 1;
>         } else {
>             borrow = 0;
>         }
>     }
> 
>     // Avoid leaking too much info 
>     *p_wait_state = ((u32)(*p_wait_state/5))*5;
>     return (result != 0); 
> }
> 
> int custom_handle_vmmcall(struct kvm_vcpu *vcpu) {
>     int ret = -1;
>     int ret_cmp = -1;
> 
>     if (unlikely(!key_initialized)) {
>         get_random_bytes(&secret_key, sizeof(secret_key));
>         key_initialized = true;
>         printk(KERN_INFO "KVMillésime: secret generated\n");
>     }
> 
>     if (0x1337 != kvm_rax_read(vcpu)) {
>         ret = kvm_emulate_hypercall(vcpu);
>     } else {
>         gpa_t userinput_addr = kvm_rcx_read(vcpu);
>         unsigned __int128 v_input = 0;
> 
>         // Read from guest land 
>         if (kvm_read_guest(vcpu->kvm, userinput_addr, &v_input, sizeof(v_input))) {
>             printk(KERN_ERR "[!] Could not read guest data\n");
>             return -EFAULT;
>         }
> 
>         unsigned int wait_state_telemetry = 0;
>     
>         ret_cmp = constant_time_compare_128(v_input, secret_key, &wait_state_telemetry);
> 
>         kvm_rax_write(vcpu, (u32)ret_cmp);          
>         kvm_rdx_write(vcpu, (u32)wait_state_telemetry);
> 
>         kvm_skip_emulated_instruction(vcpu);
>         ret = 1;
>     }
> 
>     return ret;
> }
