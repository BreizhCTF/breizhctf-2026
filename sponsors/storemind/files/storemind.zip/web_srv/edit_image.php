<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

const UPLOAD_DIR  = __DIR__ . '/uploads/';
const MAX_SIZE    = 5 * 1024 * 1024;
const MAX_DIM     = 8000;
const ALLOWED_EXT = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

function json_out(bool $ok, string $msg, int $code = 200): never {
    http_response_code($code);
    echo json_encode(['success' => $ok, 'message' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(false, 'Méthode non autorisée.', 405);
}

$name    = trim($_POST['name']    ?? '');
$dataUrl = trim($_POST['dataUrl'] ?? '');
$width   = (int)($_POST['width']  ?? 0);
$height  = (int)($_POST['height'] ?? 0);

if ($name === '' || $dataUrl === '') {
    json_out(false, 'Paramètres manquants.', 400);
}

//Sanitize du nom
$name = str_replace("\0", '', $name);
$name = basename($name);
if ($name === '' || $name === '.' || $name === '..') {
    json_out(false, 'Nom invalide.', 400);
}

$ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));

$destPath = UPLOAD_DIR . $name;
$realBase = realpath(UPLOAD_DIR);
if ($realBase === false || strpos($destPath, $realBase) !== 0) {
    json_out(false, 'Accès refusé.', 403);
}
$realDest = $destPath;

if (!preg_match('/^data:image\/(png|jpeg|jpg|gif|webp);base64,(.+)$/s', $dataUrl, $m)) {
    json_out(false, 'Format de donimagenées invalide.', 400);
}
$mimeType  = 'image/' . $m[1];
$imageData = base64_decode($m[2], true);

if ($imageData === false || strlen($imageData) === 0) {
    json_out(false, 'Décodage base64 échoué.', 400);
}

if (strlen($imageData) > MAX_SIZE) {
    json_out(false, 'Image trop volumineuse après encodage (max 5 Mo).', 413);
}

// whitelist 
if (!in_array($ext, ['jpg','jpeg','png','gif','webp'], true)) {
    if (file_put_contents($realDest, $imageData) === false) {
        json_out(false, 'Échec de la sauvegarde des données.', 500);
    }
    chmod($realDest, 0640);
    json_out(true, "Fichier « $name » sauvegardé.");
}

// Vérif du magic bytes
if (!function_exists('imagecreatefromstring')) {
    json_out(false, 'Extension GD manquante sur le serveur.', 500);
}

$img = @imagecreatefromstring($imageData);
if ($img === false) {
    json_out(false, 'Données image corrompues ou format non supporté.', 400);
}

$imgW = imagesx($img);
$imgH = imagesy($img);

if ($imgW <= 0 || $imgH <= 0 || $imgW > MAX_DIM || $imgH > MAX_DIM) {
    imagedestroy($img);
    json_out(false, "Dimensions invalides ({$imgW}×{$imgH}). Max : " . MAX_DIM . "px.", 400);
}

$saved = false;

switch ($ext) {
    case 'jpg':
    case 'jpeg':
        $bg = imagecreatetruecolor($imgW, $imgH);
        $white = imagecolorallocate($bg, 255, 255, 255);
        imagefill($bg, 0, 0, $white);
        imagecopy($bg, $img, 0, 0, 0, 0, $imgW, $imgH);
        $saved = imagejpeg($bg, $realDest, 92);
        imagedestroy($bg);
        break;

    case 'png':
        imagesavealpha($img, true);
        $saved = imagepng($img, $realDest, 6);
        break;

    case 'webp':
        imagesavealpha($img, true);
        $saved = imagewebp($img, $realDest, 90);
        break;

    case 'gif':
        $saved = imagegif($img, $realDest);
        break;
}

imagedestroy($img);

if (!$saved) {
    json_out(false, 'Échec de la sauvegarde de l\'image.', 500);
}

chmod($realDest, 0640);

json_out(true, "Image « $name » sauvegardée ({$imgW}×{$imgH}px).");
