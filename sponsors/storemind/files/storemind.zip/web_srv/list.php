<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

const UPLOAD_DIR = __DIR__ . '/uploads/';

const ALLOWED_EXT = ['txt','csv','log','md','jpg','jpeg','png','gif','webp'];

if (!is_dir(UPLOAD_DIR)) {
    echo json_encode(['success' => true, 'files' => []]);
    exit;
}

$files = [];

foreach (scandir(UPLOAD_DIR) as $entry) {
    if ($entry === '.' || $entry === '..') continue;

    $path = UPLOAD_DIR . $entry;
    if (!is_file($path)) continue;

    $ext = strtolower(pathinfo($entry, PATHINFO_EXTENSION));
    if (!in_array($ext, ALLOWED_EXT, true)) continue;

    $real = realpath($path);
    $base = realpath(UPLOAD_DIR);
    if ($real === false || strpos($real, $base) !== 0) continue;

    $files[] = [
        'name'  => $entry,
        'size'  => filesize($path),
        'mtime' => filemtime($path),
        'ext'   => $ext,
    ];
}

usort($files, fn($a, $b) => $b['mtime'] <=> $a['mtime']);

echo json_encode(['success' => true, 'files' => $files], JSON_UNESCAPED_UNICODE);
