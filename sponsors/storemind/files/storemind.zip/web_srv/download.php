<?php

declare(strict_types=1);

const UPLOAD_DIR  = __DIR__ . '/uploads/';
const ALLOWED_EXT = ['txt','csv','log','md','jpg','jpeg','png','gif','webp'];

$name = trim($_GET['file'] ?? '');
$name = str_replace("\0", '', $name);
$name = basename($name);

if ($name === '' || $name === '.' || $name === '..') {
    http_response_code(400); exit('Nom invalide.');
}

$ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
if (!in_array($ext, ALLOWED_EXT, true)) {
    http_response_code(403); exit('Extension non autorisée.');
}

$path = UPLOAD_DIR . $name;
$real = realpath($path);
$base = realpath(UPLOAD_DIR);

if ($real === false || $base === false || strpos($real, $base) !== 0) {
    http_response_code(403); exit('Accès refusé.');
}

if (!is_file($real)) {
    http_response_code(404); exit('Fichier introuvable.');
}

$finfo    = new finfo(FILEINFO_MIME_TYPE);
$mime     = $finfo->file($real) ?: 'application/octet-stream';
$filesize = filesize($real);

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . addslashes($name) . '"');
header('Content-Length: ' . $filesize);
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

readfile($real);
exit;
