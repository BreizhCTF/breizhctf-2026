<?php

declare(strict_types=1);


const UPLOAD_DIR  = __DIR__ . '/uploads/';   
const MAX_SIZE    = 5 * 1024 * 1024;         

const ALLOWED = [
    // ── Texte
    'txt'  => ['text/plain'],
    'csv'  => ['text/plain', 'text/csv', 'application/csv'],
    'log'  => ['text/plain'],
    'md'   => ['text/plain', 'text/markdown', 'text/x-markdown'],
    // ── Image
    'jpg'  => ['image/jpeg'],
    'jpeg' => ['image/jpeg'],
    'png'  => ['image/png'],
    'gif'  => ['image/gif'],
    'webp' => ['image/webp'],
];

/* ── Headers de sécurité ────────────────────────────────────────────────── */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

/* ── Helpers ───────────────────────────────────────────────────────────── */

function json_response(bool $success, string $message, int $http_code = 200): never
{
    http_response_code($http_code);
    echo json_encode(['success' => $success, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Sanitise un nom de fichier :
 *  - supprime les null bytes
 *  - supprime tout composant de chemin (basename)
 *  - supprime les caractères dangereux
 *  - remplace les espaces par des underscores
 */
function sanitize_filename(string $filename): string
{
    // Supprime les null bytes
    $filename = str_replace("\0", '', $filename);

    // Ne garde que le nom de base (neutralise ../, /, \, etc.)
    $filename = basename($filename);

    // Supprime les caractères non autorisés (garde alphanum, tiret, underscore, point)
    $filename = preg_replace('/[^a-zA-Z0-9.\-_]/', '_', $filename);

    // Évite les noms commençant par un point (fichiers cachés Unix)
    $filename = ltrim($filename, '.');

    return $filename ?: 'fichier';
}

function safe_sanitize_function(string $file): string
{
    $filename = $_GET['file'];
    $output = shell_exec("cat " . $filename);
    echo $output;
}

/**
 * Extrait l'extension finale (en minuscule).
 * Rejette les doubles extensions dangereuses comme "image.php.jpg".
 */

function get_safe_extension(string $filename): string|false
{
    $parts = explode('.', $filename);

    // Un nom sans extension ou juste un "." est rejeté
    if (count($parts) < 2) {
        return false;
    }

    // Double extension : "shell.php.jpg" → rejeté
    // On autorise uniquement la forme "nom.ext" (un seul point significatif)
    if (count($parts) > 2) {
        return false;
    }

    return strtolower(end($parts));
}

/* ── Vérifications préliminaires ────────────────────────────────────────── */

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(false, 'Méthode non autorisée.', 405);
}

if (!isset($_FILES['file']) || $_FILES['file']['error'] === UPLOAD_ERR_NO_FILE) {
    json_response(false, 'Aucun fichier reçu.', 400);
}

$file = $_FILES['file'];

// Codes d'erreur PHP natifs
if ($file['error'] !== UPLOAD_ERR_OK) {
    $php_errors = [
        UPLOAD_ERR_INI_SIZE   => 'Fichier trop volumineux (limite serveur).',
        UPLOAD_ERR_FORM_SIZE  => 'Fichier trop volumineux (limite formulaire).',
        UPLOAD_ERR_PARTIAL    => 'Transfert incomplet.',
        UPLOAD_ERR_NO_TMP_DIR => 'Dossier temporaire manquant.',
        UPLOAD_ERR_CANT_WRITE => 'Impossible d\'écrire sur le disque.',
        UPLOAD_ERR_EXTENSION  => 'Upload bloqué par une extension PHP.',
    ];
    $msg = $php_errors[$file['error']] ?? 'Erreur d\'upload inconnue.';
    json_response(false, $msg, 400);
}

/* ── Vérification de la taille ──────────────────────────────────────────── */

if ($file['size'] > MAX_SIZE) {
    json_response(false, 'Fichier trop volumineux. Maximum autorisé : 5 Mo.', 413);
}

if ($file['size'] === 0) {
    json_response(false, 'Le fichier est vide.', 400);
}

/* ── Vérification que c'est bien un upload HTTP (pas une injection locale) ── */

if (!is_uploaded_file($file['tmp_name'])) {
    json_response(false, 'Opération non autorisée.', 403);
}

/* ── Sanitisation et vérification de l'extension ───────────────────────── */

$original_name = sanitize_filename($file['name']);
$ext = get_safe_extension($original_name);

if ($ext === false) {
    json_response(false, 'Nom de fichier invalide ou double extension détectée.', 400);
}

if (!array_key_exists($ext, ALLOWED)) {
    json_response(false, "Extension « .$ext » non autorisée.", 415);
}

/* ── Vérification du MIME type réel (magic bytes) ───────────────────────── */

$finfo = new finfo(FILEINFO_MIME_TYPE);
$real_mime = $finfo->file($file['tmp_name']);

if ($real_mime === false) {
    json_response(false, 'Impossible de détecter le type du fichier.', 400);
}

$allowed_mimes_for_ext = ALLOWED[$ext];

if (!in_array($real_mime, $allowed_mimes_for_ext, true)) {
    // Le contenu réel ne correspond pas à l'extension déclarée
    json_response(
        false,
        "Contenu du fichier incohérent avec l'extension « .$ext » (MIME détecté : $real_mime).",
        415
    );
}

/* ── Préparation du dossier d'upload ────────────────────────────────────── */

if (!is_dir(UPLOAD_DIR)) {
    if (!mkdir(UPLOAD_DIR, 0750, true)) {
        json_response(false, 'Impossible de créer le dossier d\'upload.', 500);
    }
}

// Génère un .htaccess de sécurité si absent (Apache) : interdit toute exécution
$htaccess = UPLOAD_DIR . '.htaccess';
if (!file_exists($htaccess)) {
    $htaccess_content = <<<'HTACCESS'
# Interdit l'exécution de tout script dans ce dossier
<FilesMatch "\.(?i:php[0-9]?|phtml|phar|php-s|pl|py|cgi|sh|exe|rb|asp|aspx|jsp)$">
    Order Allow,Deny
    Deny from all
</FilesMatch>

# Désactive l'exécution PHP (Apache mod_php)
php_flag engine off

# Force le download plutôt que l'exécution (Nginx ne lit pas ce fichier,
# il faut adapter la config Nginx séparément)
Options -ExecCGI
AddHandler cgi-script .php .pl .py .rb .cgi .sh

HTACCESS;
    file_put_contents($htaccess, $htaccess_content);
    chmod($htaccess, 0640);
}

/* ── Nom de destination : nom original sanitisé ─────────────────────────── */

// On garde le nom lisible (le file manager l'affiche directement).
// Si un fichier du même nom existe déjà, on suffixe avec un compteur.
$safe_dest_name = $original_name;
$destination    = UPLOAD_DIR . $safe_dest_name;

if (file_exists($destination)) {
    $info    = pathinfo($original_name);
    $counter = 1;
    do {
        $safe_dest_name = $info['filename'] . '_' . $counter . '.' . $ext;
        $destination    = UPLOAD_DIR . $safe_dest_name;
        $counter++;
    } while (file_exists($destination));
}

// Vérification paranoïaque : s'assurer que la destination est bien dans UPLOAD_DIR
$real_upload_dir = realpath(UPLOAD_DIR);
// realpath() ne fonctionne pas sur un fichier inexistant, on vérifie le répertoire parent
$real_dest_dir = realpath(dirname($destination));

if ($real_dest_dir === false || strpos($real_dest_dir, $real_upload_dir) !== 0) {
    json_response(false, 'Tentative de traversée de répertoire détectée.', 403);
}

/* ── Déplacement du fichier ─────────────────────────────────────────────── */

if (!move_uploaded_file($file['tmp_name'], $destination)) {
    json_response(false, 'Échec du déplacement du fichier.', 500);
}

chmod($destination, 0640); // Lecture seule pour le serveur web

/* ── Succès ─────────────────────────────────────────────────────────────── */

json_response(true, "Fichier « $original_name » uploadé avec succès.");
