<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

const UPLOAD_DIR  = __DIR__ . '/uploads/';
const ALLOWED_EXT = ['txt','csv','log','md','jpg','jpeg','png','gif','webp'];

function json_out(bool $ok, string $msg, int $code = 200): never {
    http_response_code($code);
    echo json_encode(['success' => $ok, 'message' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(false, 'Méthode non autorisée.', 405);
}

$name = trim($_POST['name'] ?? '');

if ($name === '') {
    json_out(false, 'Nom de fichier manquant.', 400);
}

// Sanitise : basename uniquement, supprime null bytes
$name = str_replace("\0", '', $name);
$name = basename($name);

if ($name === '' || $name === '.' || $name === '..') {
    json_out(false, 'Nom invalide.', 400);
}

// Vérification de l'extension
$ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
if (!in_array($ext, ALLOWED_EXT, true)) {
    json_out(false, 'Extension non autorisée.', 403);
}

$path = UPLOAD_DIR . $name;

// Résolution réelle du chemin pour bloquer tout traversal
$real = realpath($path);
$base = realpath(UPLOAD_DIR);

if ($real === false || $base === false || strpos($real, $base) !== 0) {
    json_out(false, 'Accès refusé.', 403);
}

if (!is_file($real)) {
    json_out(false, 'Fichier introuvable.', 404);
}

if (!unlink($real)) {
    json_out(false, 'Impossible de supprimer le fichier.', 500);
}

json_out(true, "Fichier « $name » supprimé.");
