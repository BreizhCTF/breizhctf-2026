<?php

function getFile($filename) {
    $basePath = __DIR__ . "/";
    $url = $basePath . $filename;
    return file_get_contents($url);
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SNAKE</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@400;700;900&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg:        #020c06;
    --grid:      #051a0a;
    --snake:     #00ff6a;
    --snake2:    #00c44f;
    --head:      #ffffff;
    --food:      #ff3c5a;
    --food-glow: #ff3c5a88;
    --text:      #00ff6a;
    --dim:       #1a4d2a;
    --ui-bg:     #040f07;
  }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Share Tech Mono', monospace;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    overflow: hidden;
    user-select: none;
  }

  body::before {
    content: '';
    position: fixed;
    inset: 0;
    background: repeating-linear-gradient(
      0deg,
      transparent,
      transparent 2px,
      rgba(0,0,0,0.15) 2px,
      rgba(0,0,0,0.15) 4px
    );
    pointer-events: none;
    z-index: 100;
  }

  h1 {
    font-family: 'Orbitron', monospace;
    font-weight: 900;
    font-size: clamp(1.8rem, 5vw, 3rem);
    letter-spacing: 0.3em;
    color: var(--snake);
    text-shadow: 0 0 20px var(--snake), 0 0 60px var(--snake2);
    margin-bottom: 1rem;
    animation: flicker 6s infinite;
  }

  @keyframes flicker {
    0%,95%,100% { opacity: 1; }
    96% { opacity: 0.85; }
    97% { opacity: 1; }
    98% { opacity: 0.7; }
    99% { opacity: 1; }
  }

  .hud {
    display: flex;
    gap: 3rem;
    margin-bottom: 0.8rem;
    font-size: 0.9rem;
    letter-spacing: 0.15em;
    color: var(--dim);
  }

  .hud span { color: var(--text); }

  #gameCanvas {
    display: block;
    border: 1px solid var(--dim);
    box-shadow: 0 0 0 1px var(--dim),
                0 0 30px rgba(0,255,106,0.15),
                inset 0 0 30px rgba(0,0,0,0.5);
    image-rendering: pixelated;
    cursor: none;
  }

  .hint {
    margin-top: 0.8rem;
    font-size: 0.75rem;
    color: var(--dim);
    letter-spacing: 0.1em;
  }

  /* Overlay message (game over / start) */
  #overlay {
    position: absolute;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 1rem;
    pointer-events: none;
  }

  #overlay.hidden { display: none; }

  #overlay .big {
    font-family: 'Orbitron', monospace;
    font-weight: 700;
    font-size: clamp(1.2rem, 4vw, 2rem);
    letter-spacing: 0.2em;
    color: var(--food);
    text-shadow: 0 0 20px var(--food);
  }

  #overlay .sub {
    font-size: 0.8rem;
    letter-spacing: 0.15em;
    color: var(--text);
    animation: blink 1.1s step-end infinite;
  }

  @keyframes blink {
    0%,100% { opacity: 1; }
    50% { opacity: 0; }
  }

  #overlay .score-display {
    font-size: 1rem;
    color: var(--dim);
    letter-spacing: 0.1em;
  }
  #overlay .score-display span { color: var(--text); }
</style>
</head>
<body>

<h1>SNAKE</h1>

<div class="hud">
  SCORE &nbsp;<span id="scoreDisplay">0</span>
  &nbsp;&nbsp;&nbsp;
  MEILLEUR &nbsp;<span id="hiDisplay">0</span>
</div>

<div style="position:relative; line-height:0;">
  <canvas id="gameCanvas"></canvas>
  <div id="overlay">
    <div class="big" id="overlayTitle">SNAKE</div>
    <div class="score-display" id="overlayScore" style="display:none">
      SCORE &nbsp;<span id="overlayScoreVal">0</span>
    </div>
    <div class="sub">APPUYER SUR UNE TOUCHE</div>
  </div>
</div>

<div class="hint">↑ ↓ ← → &nbsp;·&nbsp; ESPACE = pause</div>

<script>
(() => {
  const COLS       = 28;
  const ROWS       = 28;
  const CELL       = Math.min(Math.floor((window.innerHeight * 0.68) / ROWS),
                              Math.floor((window.innerWidth  * 0.88) / COLS));
  const W          = COLS * CELL;
  const H          = ROWS * CELL;
  const BASE_SPEED = 120;   // ms par tick (plus bas = plus rapide)

  const canvas  = document.getElementById('gameCanvas');
  canvas.width  = W;
  canvas.height = H;
  const ctx     = canvas.getContext('2d');

  const scoreEl    = document.getElementById('scoreDisplay');
  const hiEl       = document.getElementById('hiDisplay');
  const overlay    = document.getElementById('overlay');
  const ovTitle    = document.getElementById('overlayTitle');
  const ovScore    = document.getElementById('overlayScore');
  const ovScoreVal = document.getElementById('overlayScoreVal');

  let snake, dir, nextDir, food, score, hi = 0;
  let running = false, paused = false, dead = false, flagPause = false;
  let lastTime = 0, acc = 0;
  let speed = BASE_SPEED;
  let foodPulse = 0; // animation nourriture
  let flagShown = false; // message 15 points

  function init() {
    const cx = Math.floor(COLS / 2);
    const cy = Math.floor(ROWS / 2);
    snake   = [{x:cx, y:cy}, {x:cx-1, y:cy}, {x:cx-2, y:cy}];
    dir     = {x:1, y:0};
    nextDir = {x:1, y:0};
    score      = 0;
    speed      = BASE_SPEED;
    flagShown  = false;
    flagPause  = false;
    placeFood();
    updateHUD();
  }

  function placeFood() {
    let pos;
    do {
      pos = { x: Math.floor(Math.random()*COLS), y: Math.floor(Math.random()*ROWS) };
    } while (snake.some(s => s.x===pos.x && s.y===pos.y));
    food = pos;
  }

  function loop(ts) {
    if (!running) return;
    const dt = ts - lastTime;
    lastTime = ts;

    foodPulse = (foodPulse + dt * 0.004) % (Math.PI * 2);

    if (!paused && !dead && !flagPause) {
      acc += dt;
      if (acc >= speed) {
        acc -= speed;
        tick();
      }
    }

    draw();
    requestAnimationFrame(loop);
  }

  function tick() {
    dir = { ...nextDir };
    const head = { x: (snake[0].x + dir.x + COLS) % COLS,
                   y: (snake[0].y + dir.y + ROWS) % ROWS };

    if (snake.some(s => s.x===head.x && s.y===head.y)) {
      gameOver(); return;
    }

    snake.unshift(head);

    if (head.x===food.x && head.y===food.y) {
      score++;
      if (score > hi) hi = score;
      // Accélère légèrement
      speed = Math.max(55, BASE_SPEED - score * 3);
      updateHUD();
      placeFood();
      if (score === 7 && !flagShown) {
        flagShown = true;
        showFlagToast();
      }
    } else {
      snake.pop();
    }
  }

  function showFlagToast() {
    flagPause = true;
    paused    = false;

    const box = document.createElement('div');
    box.id = 'flagBox';
    box.innerHTML = `
      <div style="font-family:'Orbitron',monospace;font-weight:700;font-size:clamp(1rem,3vw,1.4rem);
                  color:#ff3c5a;text-shadow:0 0 18px #ff3c5a;letter-spacing:.15em;margin-bottom:.6rem;">
        ⚑ &nbsp;INTERRUPTION &nbsp;⚑
      </div>
      <div style="font-size:.9rem;color:#00ff6a;letter-spacing:.1em;margin-bottom:1.2rem;line-height:1.6;">
        bon, il serait pas le temps de flag maintenant ??? 🚩🚩 (-10 points pour la peine) <br>
        <span style="color:#1a4d2a;font-size:.78rem;">(−10 points à la reprise)</span>
      </div>
      <div style="font-size:.75rem;color:#00ff6a;animation:blink 1.1s step-end infinite;letter-spacing:.15em;">
        APPUYER SUR UNE TOUCHE
      </div>`;
    box.style.cssText = `
      position:absolute; inset:0;
      display:flex; flex-direction:column;
      align-items:center; justify-content:center;
      background:rgba(2,12,6,0.88);
      text-align:center; padding:1rem;
      z-index:50;
    `;
    canvas.parentNode.appendChild(box);
  }

  function resumeAfterFlag() {
    const box = document.getElementById('flagBox');
    if (box) box.remove();
    score     = Math.max(0, score - 10);
    flagPause = false;
    updateHUD();
    // Raccourcit le serpent de 10 segments si possible
    if (snake.length > 13) snake.splice(13);
  }

  function gameOver() {
    dead = true;
    ovTitle.textContent    = 'GAME OVER';
    ovTitle.style.color    = 'var(--food)';
    ovTitle.style.textShadow = '0 0 20px var(--food)';
    ovScoreVal.textContent = score;
    ovScore.style.display  = 'block';
    overlay.classList.remove('hidden');
  }

  function draw() {
    ctx.fillStyle = '#020c06';
    ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = '#051a0a';
    ctx.lineWidth = 0.5;
    for (let x = 0; x <= COLS; x++) {
      ctx.beginPath(); ctx.moveTo(x*CELL, 0); ctx.lineTo(x*CELL, H); ctx.stroke();
    }
    for (let y = 0; y <= ROWS; y++) {
      ctx.beginPath(); ctx.moveTo(0, y*CELL); ctx.lineTo(W, y*CELL); ctx.stroke();
    }

    const pulse = 0.7 + 0.3 * Math.sin(foodPulse);
    const fr = food.x * CELL;
    const ft = food.y * CELL;
    const fc = CELL / 2;
    const radius = (CELL * 0.35) * pulse;

    ctx.save();
    ctx.shadowColor = '#ff3c5a';
    ctx.shadowBlur  = 12 * pulse;
    ctx.fillStyle   = '#ff3c5a';
    ctx.beginPath();
    ctx.arc(fr + fc, ft + fc, radius, 0, Math.PI*2);
    ctx.fill();
    ctx.restore();

    for (let i = snake.length - 1; i >= 0; i--) {
      const s   = snake[i];
      const px  = s.x * CELL + 1;
      const py  = s.y * CELL + 1;
      const sz  = CELL - 2;

      if (i === 0) {
        ctx.save();
        ctx.shadowColor = '#00ff6a';
        ctx.shadowBlur  = 14;
        ctx.fillStyle   = '#ffffff';
        roundRect(ctx, px, py, sz, sz, 3);
        ctx.fill();
        ctx.restore();

        const ex = dir.x, ey = dir.y;
        const eyeOffset = sz * 0.22;
        const eyeSize   = sz * 0.12;
        ctx.fillStyle = '#020c06';

        const perp = { x: -ey, y: ex };
        const baseX = px + sz/2 + ex * sz * 0.22;
        const baseY = py + sz/2 + ey * sz * 0.22;
        ctx.beginPath();
        ctx.arc(baseX + perp.x*eyeOffset, baseY + perp.y*eyeOffset, eyeSize, 0, Math.PI*2);
        ctx.arc(baseX - perp.x*eyeOffset, baseY - perp.y*eyeOffset, eyeSize, 0, Math.PI*2);
        ctx.fill();

      } else {
        const t = i / snake.length;
        const g = Math.round(180 + (1-t)*75);
        ctx.fillStyle = `rgb(0,${g},60)`;
        ctx.save();
        if (dead) { ctx.globalAlpha = 0.6; }
        roundRect(ctx, px, py, sz, sz, 2);
        ctx.fill();
        ctx.restore();
      }
    }

    if (paused && !dead) {
      ctx.fillStyle = 'rgba(2,12,6,0.6)';
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = '#00ff6a';
      ctx.font = `bold ${CELL*2}px 'Orbitron', monospace`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('PAUSE', W/2, H/2);
    }
  }

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x+r, y);
    ctx.lineTo(x+w-r, y);
    ctx.quadraticCurveTo(x+w, y, x+w, y+r);
    ctx.lineTo(x+w, y+h-r);
    ctx.quadraticCurveTo(x+w, y+h, x+w-r, y+h);
    ctx.lineTo(x+r, y+h);
    ctx.quadraticCurveTo(x, y+h, x, y+h-r);
    ctx.lineTo(x, y+r);
    ctx.quadraticCurveTo(x, y, x+r, y);
    ctx.closePath();
  }

  function updateHUD() {
    scoreEl.textContent = score;
    hiEl.textContent    = hi;
  }

  const DIRS = {
    ArrowUp:    {x:0,  y:-1},
    ArrowDown:  {x:0,  y:1},
    ArrowLeft:  {x:-1, y:0},
    ArrowRight: {x:1,  y:0},
  };

  document.addEventListener('keydown', e => {
    if (e.key === ' ') {
      e.preventDefault();
      if (flagPause) { resumeAfterFlag(); return; }
      if (!running || dead) return;
      paused = !paused;
      return;
    }

    const d = DIRS[e.key];
    if (d) {
      e.preventDefault();

      if (flagPause) {
        resumeAfterFlag();
        return;
      }

      if (!running || dead) {
        init();
        overlay.classList.add('hidden');
        ovScore.style.display = 'none';
        ovTitle.textContent   = 'SNAKE';
        ovTitle.style.color   = 'var(--snake)';
        ovTitle.style.textShadow = '0 0 20px var(--snake)';
        running = true;
        paused  = false;
        dead    = false;
        lastTime = performance.now();
        acc = 0;
        requestAnimationFrame(loop);
        return;
      }

      if (d.x === -dir.x && d.y === -dir.y) return;
      nextDir = d;
    }
  });

  init();
  draw(); 
})();
</script>
</body>
</html>
